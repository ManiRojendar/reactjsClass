import React from 'react';
import './App.css';
import Header from './Header/index';
import Footer from './Footer/index';
import Menu from './Menu/index';
import MenuWithOutHash from './MenuWithOutHash/index'
function App() {
  return (
    <div className="App">
        <Header />
        {/* <Menu /> */}
        <MenuWithOutHash />
        <Footer />

    </div>
  );
}

export default App;
