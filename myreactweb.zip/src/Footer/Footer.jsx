import "./Footer.css";
import React from "react";

function template() {
  return (
    <div className="footer">
      &copy; rights belongs to me
    </div>
  );
};

export default template;
