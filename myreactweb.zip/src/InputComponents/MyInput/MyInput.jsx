import "./MyInput.css";
import React from "react";

function template() {
 const {lbl,type,id} =this.props;
  return (
    <p className="my-input">
         <b>{lbl}</b> : <input id={id} type={type} onChange={this.fnChange.bind(this)} />
    </p>
  );
};

export default template;
