import "./Users.css";
import React from "react";
import MyInput from '../InputComponents/MyInput';
function template() {
  return (
    <div className="users">
      <h1>Users</h1>
      <MyInput lbl="Name" type="text" id="name" fnPrepareData={this.fnPrepareData} />
      <MyInput lbl="Rno" type="text" id="rno" fnPrepareData={this.fnPrepareData} />
      <MyInput lbl="Email" type="text" id="email" fnPrepareData={this.fnPrepareData} />
      <MyInput lbl="Location" type="text" id="loc" fnPrepareData={this.fnPrepareData} />
      <input type='button' value='register' onClick={this.fnReg.bind(this)} />
    </div>
  );
};

export default template;
