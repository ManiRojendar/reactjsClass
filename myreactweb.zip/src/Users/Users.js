import React    from "react";
import template from "./Users.jsx";
import ServerCall from '../services/ServerCall';
class Users extends React.Component {
  constructor(){
    super();
    this.state={
      'dataObj':{}
    }
    this.fnPrepareData=this.fnPrepareData.bind(this);
  }
  render() {
    return template.call(this);
  }

  fnPrepareData(key,value){
      this.setState({
        dataObj:{
          ...this.state.dataObj,
          [key]:value
        }
      })
  }

  fnReg(){
    ServerCall.fnPostReq('http://localhost:2020/users/std-reg',this.state.dataObj)
    .then(
      (res)=>{
        debugger;
      }
    )
    .catch(()=>{
      debugger;
    })
  }
}

export default Users;
