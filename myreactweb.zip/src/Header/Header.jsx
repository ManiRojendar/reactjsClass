import "./Header.css";
import React from "react";

function template() {
  return (
    <div className="header">
        My React App 
    </div>
  );
};

export default template;
