var mysql=require('mysql');
var sharedObj={};

sharedObj.getMysqlCon=function(res,cb){
    var con=mysql.createConnection({
        'host':'localhost',
        'user':'root',
        'password':'',
        'database':'react270919'
    })

    con.connect(function(err){
        if(err){
            res.send('db conn error');
        }

        cb(con);

    })
}

sharedObj.getMongoCon=function(){

}

module.exports=sharedObj;