var express=require('express');
var router=express.Router();
var sharedObj=require('./shared');

router.post('/std-reg',function(req,res){
     var name=req.body.name;
     var rno=req.body.rno;
     var email=req.body.email;
     var loc=req.body.loc;


     sharedObj.getMysqlCon(
        res,
        function(con){
           var q="insert into users(name,rno,email,loc) values('"+name+"','"+rno+"','"+email+"','"+loc+"')";
           con.query(q,function(e,s){
            if(e){
              res.send(e);
            }else{
              res.send(s);
            }
           })
        }
     )
})




module.exports=router;